from django.shortcuts import render,HttpResponse
from .models import Employee,Role,Department
# Create your views here.
def index(request):
    return  render(request,'index.html')

def view(request):
    emps = Employee.objects.all()
    context = {
        'emps':emps
    }
    print(context)
    return render (request,'view.html',context)

def add(request):
    if request.method == 'POST':
       
       first_name = request.POST['first_name']
       last_name = request.POST['last_name']
       salary =int(request.POST['salary'])
       bonus = int(request.POST['bonus'])

       role = request.POST['role']
       dept = request.POST['dept']

       phone = request.POST['phone']
       new_emp  = Employee(first_name=first_name, last_name=last_name , salary=salary,bonus=bonus ,role=role,dept = dept,phone=phone)
       new_emp.save()
       return HttpResponse('sucessfuly register')
    
    return render (request,'add.html')


def remove(request, emp_id = 0):
    if  emp_id:
        try:
            emp_to_be_removed =Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse('Employe remove sucessfully')

        except:
            return HttpResponse('plz enter valid emp id')
    emps=Employee.objects.all()
    context = {
        'emps' :emps
    }
    return render (request,'remove.html',context)


def filter(request):
    return render (request,'filter.html')


